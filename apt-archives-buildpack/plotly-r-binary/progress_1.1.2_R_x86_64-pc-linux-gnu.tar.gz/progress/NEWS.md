
# 1.1.2

* Do not run tests on CRAN, Solaris does not have microbenchmark

# 1.1.1

* Move README.md, so that it is not parsed on CRAN
* Use https URLs instead of http, whenever possible

# 1.1.0

* Support for the `:spin` token which adds a simple ASCII spinner, @richfitz
* Respect custom token width for calculation of the bar width, @mllg

# 1.0.2

* Fix the C++ API on Windows, and on older compilers in general.

# 1.0.1

First version on CRAN.
