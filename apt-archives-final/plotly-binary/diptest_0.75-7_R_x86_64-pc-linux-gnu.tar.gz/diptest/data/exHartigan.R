message("'exHartigan' data is identical to 'statfaculty' and hence deprecated.",
        "\n Use the 'statfaculty' instead")
source("statfaculty.R")
exHartigan <- statfaculty
